module.exports = {
  plugins: {
    'tailwindcss/nesting': {},
    tailwindcss: { config: './tailwind.config.cjs' },
    autoprefixer: {},
  },
}
