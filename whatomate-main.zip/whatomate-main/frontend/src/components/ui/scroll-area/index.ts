export { default as ScrollArea } from './ScrollArea.vue'
