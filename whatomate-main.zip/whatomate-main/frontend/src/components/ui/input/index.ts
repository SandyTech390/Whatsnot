export { default as Input } from './Input.vue'
